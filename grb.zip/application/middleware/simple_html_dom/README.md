# :warning: NUDE PICS!!!, KEEP READING! :warning:

<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />

Now that I got your attention, let me tell you something about this repo.

### This repo needs some love

I forked this this repo from [sourceforge](http://simplehtmldom.sourceforge.net/) long time ago just to include it on [Packagist](https://packagist.org/) in order to use it with [Composer](https://getcomposer.org/).

People started forking and staring the repo and sending issues and PR's. The thing is that I don't have the time and I no longer do PHP and honestly I don't have the time to go over the (although few) issues and start tackling them.

I actually contacted the author, S. C. Chen ([me578022@users.sourceforge.net](mailto:me578022@users.sourceforge.net)) to transfer the repo ownership with no luck.

Please, if this tool is useful to you, and you have the time needed to maintain a tool for the community, please contact me at [saul.martinez05@gmail.com](mailto:saul.martinez05@gmail.com).

Sincerly, Saul Martínez.
